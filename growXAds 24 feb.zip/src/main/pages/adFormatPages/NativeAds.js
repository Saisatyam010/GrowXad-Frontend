import React from 'react'
import NativeAd from '../../components/AdFormat/NativeAd/NativeAd'

const NativeAds = () => {
  return (
    <div>
        <NativeAd/>
    </div>
  )
}

export default NativeAds