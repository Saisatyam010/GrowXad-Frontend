import React from 'react'
import PopunderAd from '../../components/AdFormat/PopunderAd/PopunderAd'

const PopunderAds = () => {
  return (
    <div>
        <PopunderAd/>
    </div>
  )
}

export default PopunderAds