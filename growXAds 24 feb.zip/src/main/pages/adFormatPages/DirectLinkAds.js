import React from 'react'
import DirectLinkAd from '../../components/AdFormat/Direct_Link/DirectLinkAd'

const DirectLinkAds = () => {
  return (
    <div>
        <DirectLinkAd/>

    </div>
  )
}

export default DirectLinkAds