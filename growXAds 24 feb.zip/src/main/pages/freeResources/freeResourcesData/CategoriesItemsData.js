export const CategoriesItemsData = [
    {
        title: "Affiliate Marketing & Advertising"
    },
    {
        title: "Display Advertising"
    },
    {
        title: "Search Engine Marketing (SEM)"
    },
    {
        title: "Search Engine Optimization (SEO)"
    },
    {
        title: "Social Media Marketing (SMM)"
    },
    {
        title: "Influencer Marketing"
    },
    {
        title: "Content Marketing"
    },
    {
        title: "Email Marketing"
    },
    {
        title: "Native Advertising"
    },
    {
        title: "Video Advertising"
    },
    {
        title: "Mobile Advertising"
    },
    {
        title: "Contextual Advertising"
    },
    {
        title: "Programmatic Advertising"
    },
    {
        title: "Ad Networks"
    },
    {
        title: "Pay-Per-Click (PPC)"
    },
    {
        title: "Cost-Per-Impression (CPM)"
    },
    {
        title: "Cost-Per-Action (CPA)"
    },
    {
        title: "Cost-Per-Click (CPC)"
    },
    {
        title: "Cost-Per-View (CPV)"
    },
    {
        title: "Retargeting/Remarketing"
    },
]