export const HowToAdvertiseData = [
    {
        id: 1,
        title: "Mastering the Art of Advertising:",
        content: "Affiliate embraces native advertising promotional content that resonates audiences, how to advertise.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/5290476b-5cd6-4044-e83c-6b0dbe07ca00/public"
    },
    {
        id: 2,
        title: "Partnerships and Collaborations:",
        content: "Learn about recent partnerships and collaborations between technology companies, advertisers, and publishers, and how these alliances are advertising.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/e0dab2d0-1148-425d-36b4-db2cbd23ce00/public"
    },
    {
        id: 3,
        title: "Apple's App Tracks Transparency:",
        content: "Explore how Apple's App Tracking Transparency (ATT) policy is affecting ad targeting, and how advertisers are adjusting their strategies",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/d681584c-03fa-4cb7-e170-9916d1d3a700/public"
    },
    {
        id: 4,
        title: "Innovations in Ad Creative:",
        content: "Look into ad creative, such as interactive and immersive formats, and how these innovations impact user engagement and monetization.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/b82ccfe6-574a-4a6d-bea3-4ccfffa77400/public"
    },
    {
        id: 7,
        title: "Mastering the Art of Advertising:",
        content: "Affiliate embraces native advertising promotional content that resonates audiences, leading to enhanced user engagement and trust.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/5290476b-5cd6-4044-e83c-6b0dbe07ca00/public"
    },
    {
        id: 8,
        title: "Partnerships and Collaborations:",
        content: "Learn about recent partnerships and collaborations between technology companies, advertisers, and publishers, and how these alliances are advertising.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/e0dab2d0-1148-425d-36b4-db2cbd23ce00/public"
    },
    {
        id: 9,
        title: "Partnerships and Collaborations:",
        content: "Learn about recent partnerships and collaborations between technology companies, advertisers, and publishers, and how these alliances are advertising.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/e0dab2d0-1148-425d-36b4-db2cbd23ce00/public"
    },
    {
        id: 10,
        title: "Partnerships and Collaborations:",
        content: "Learn about recent partnerships and collaborations between technology companies, advertisers, and publishers, and how these alliances are advertising.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/e0dab2d0-1148-425d-36b4-db2cbd23ce00/public"
    },
    {
        id: 11,
        title: "Partnerships and Collaborations:",
        content: "Learn about recent partnerships and collaborations between technology companies, advertisers, and publishers, and how these alliances are advertising.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/e0dab2d0-1148-425d-36b4-db2cbd23ce00/public"
    },
    {
        id: 12,
        title: "Partnerships and Collaborations:",
        content: "Learn about recent partnerships and collaborations between technology companies, advertisers, and publishers, and how these alliances are advertising.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/e0dab2d0-1148-425d-36b4-db2cbd23ce00/public"
    },
]