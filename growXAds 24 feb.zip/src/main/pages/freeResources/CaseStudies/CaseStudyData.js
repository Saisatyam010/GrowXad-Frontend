export const CaseStudyData = [
    {
        title: "Publisher G Enhances User Experience:",
        content: "Publisher G integrates AI technology to personalize ad content, delivering a tailored and a boost in ad conversion rates.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/3ebe0227-37e5-49f3-9c8a-1cba32b74000/public"
    },
    {
        title: "Publisher Revenue Soars:",
        content: "Publisher C diversifies its ad partnerships, unlocking new revenue streams and achieving record-breaking profits in a quarter.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/1da01b63-635a-4da4-e900-d83a37e01000/public"
    },
    {
        title: "How Publisher Navigates Trends :",
        content: "Publisher adopts a dynamic approach, adjusting ad campaigns based on real-time market trends, resulting in increased ad effectiveness.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/f1c62acd-632e-4429-2aec-3dd4660baf00/public"
    },
    {
        title: "Publisher Z Robust Security Measures :",
        content: "Publisher G integrates AI technology to personalize ad content, delivering a experience for users and a boost in ad conversion rates..",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/026e4a5d-d2cf-4be1-0dfe-3afa48faca00/public"
    },
    {
        title: "Publisher G Enhances User Experience:",
        content: "Publisher G integrates AI technology to personalize ad content, delivering a tailored and a boost in ad conversion rates.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/3ebe0227-37e5-49f3-9c8a-1cba32b74000/public"
    },
    {
        title: "Publisher Revenue Soars:",
        content: "Publisher C diversifies its ad partnerships, unlocking new revenue streams and achieving record-breaking profits in a quarter.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/1da01b63-635a-4da4-e900-d83a37e01000/public"
    },
    {
        title: "How Publisher Navigates Trends :",
        content: "Publisher adopts a dynamic approach, adjusting ad campaigns based on real-time market trends, resulting in increased ad effectiveness.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/f1c62acd-632e-4429-2aec-3dd4660baf00/public"
    },
    {
        title: "Publisher Z Robust Security Measures :",
        content: "Publisher G integrates AI technology to personalize ad content, delivering a experience for users and a boost in ad conversion rates..",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/026e4a5d-d2cf-4be1-0dfe-3afa48faca00/public"
    },
    {
        title: "Publisher G Enhances User Experience:",
        content: "Publisher G integrates AI technology to personalize ad content, delivering a tailored and a boost in ad conversion rates.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/3ebe0227-37e5-49f3-9c8a-1cba32b74000/public"
    },
    {
        title: "Publisher Revenue Soars:",
        content: "Publisher C diversifies its ad partnerships, unlocking new revenue streams and achieving record-breaking profits in a quarter.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/1da01b63-635a-4da4-e900-d83a37e01000/public"
    },
    {
        title: "How Publisher Navigates Trends :",
        content: "Publisher adopts a dynamic approach, adjusting ad campaigns based on real-time market trends, resulting in increased ad effectiveness.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/f1c62acd-632e-4429-2aec-3dd4660baf00/public"
    },
    {
        title: "Publisher Z Robust Security Measures :",
        content: "Publisher G integrates AI technology to personalize ad content, delivering a experience for users and a boost in ad conversion rates..",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/026e4a5d-d2cf-4be1-0dfe-3afa48faca00/public"
    },
    {
        title: "Publisher G Enhances User Experience:",
        content: "Publisher G integrates AI technology to personalize ad content, delivering a tailored and a boost in ad conversion rates.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/3ebe0227-37e5-49f3-9c8a-1cba32b74000/public"
    },
    {
        title: "Publisher Revenue Soars:",
        content: "Publisher C diversifies its ad partnerships, unlocking new revenue streams and achieving record-breaking profits in a quarter.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/1da01b63-635a-4da4-e900-d83a37e01000/public"
    },
    {
        title: "How Publisher Navigates Trends :",
        content: "Publisher adopts a dynamic approach, adjusting ad campaigns based on real-time market trends, resulting in increased ad effectiveness.",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/f1c62acd-632e-4429-2aec-3dd4660baf00/public"
    },
    {
        title: "Publisher Z Robust Security Measures :",
        content: "Publisher G integrates AI technology to personalize ad content, delivering a experience for users and a boost in ad conversion rates..",
        date: "Updated : 22nd December 2023",
        imgPath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/026e4a5d-d2cf-4be1-0dfe-3afa48faca00/public"
    },
   
]