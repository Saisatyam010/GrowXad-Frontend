export const HowToAdvertiseData = [
    {
        title: "Techniques for Superior Results:",
        content: "Advertisers are honing in on precision employing advanced targeting techniques to reach their ideal customers with accuracy, resulting in higher conversion rates.",
        date: "Updated : 22nd December 2023",
        imgPath: "	https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/d3aa2549-d47a-49d3-013a-994754c29100/public"
    },
    {
        title: "How to Monetize Social Media Platforms :",
        content: "Brands are tapping into the social commerce trend, seamlessly integrating e-commerce capabilities into their social media strategies for increased conversions and revenue.",
        date: "Updated : 22nd December 2023",
        imgPath: "	https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/3cdd0f09-80b2-432a-ae82-61a79e558f00/public"
    },
    {
        title: "Data Privacy Revolution :",
        content: "In response to growing concerns about data privacy, Publisher F introduces robust measures to protect user data, commitment to user privacy and compliance.",
        date: "Updated : 22nd December 2023",
        imgPath: "	https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/e82e5f19-900f-4419-5732-1275f0f00e00/public"
    },
    {
        title: "Gamification in Ads :",
        content: "Brand K introduces gamification elements in its advertising campaigns, enhancing user engagement and interaction through interactive and entertaining content.",
        date: "Updated : 22nd December 2023",
        imgPath: "	https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/b3a8ab85-28b7-4a83-bd8a-eb96d2ed5500/public"
    },
    {
        title: "Techniques for Superior Results:",
        content: "Advertisers are honing in on precision employing advanced targeting techniques to reach their ideal customers with accuracy, resulting in higher conversion rates.",
        date: "Updated : 22nd December 2023",
        imgPath: "	https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/d3aa2549-d47a-49d3-013a-994754c29100/public"
    },
    {
        title: "How to Monetize Social Media Platforms :",
        content: "Brands are tapping into the social commerce trend, seamlessly integrating e-commerce capabilities into their social media strategies for increased conversions and revenue.",
        date: "Updated : 22nd December 2023",
        imgPath: "	https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/3cdd0f09-80b2-432a-ae82-61a79e558f00/public"
    },
    {
        title: "Data Privacy Revolution :",
        content: "In response to growing concerns about data privacy, Publisher F introduces robust measures to protect user data, commitment to user privacy and compliance.",
        date: "Updated : 22nd December 2023",
        imgPath: "	https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/e82e5f19-900f-4419-5732-1275f0f00e00/public"
    },
    {
        title: "Gamification in Ads :",
        content: "Brand K introduces gamification elements in its advertising campaigns, enhancing user engagement and interaction through interactive and entertaining content.",
        date: "Updated : 22nd December 2023",
        imgPath: "	https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/b3a8ab85-28b7-4a83-bd8a-eb96d2ed5500/public"
    },
    {
        title: "Techniques for Superior Results:",
        content: "Advertisers are honing in on precision employing advanced targeting techniques to reach their ideal customers with accuracy, resulting in higher conversion rates.",
        date: "Updated : 22nd December 2023",
        imgPath: "	https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/d3aa2549-d47a-49d3-013a-994754c29100/public"
    },
    {
        title: "How to Monetize Social Media Platforms :",
        content: "Brands are tapping into the social commerce trend, seamlessly integrating e-commerce capabilities into their social media strategies for increased conversions and revenue.",
        date: "Updated : 22nd December 2023",
        imgPath: "	https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/3cdd0f09-80b2-432a-ae82-61a79e558f00/public"
    },
    {
        title: "Data Privacy Revolution :",
        content: "In response to growing concerns about data privacy, Publisher F introduces robust measures to protect user data, commitment to user privacy and compliance.",
        date: "Updated : 22nd December 2023",
        imgPath: "	https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/e82e5f19-900f-4419-5732-1275f0f00e00/public"
    },
    {
        title: "Gamification in Ads :",
        content: "Brand K introduces gamification elements in its advertising campaigns, enhancing user engagement and interaction through interactive and entertaining content.",
        date: "Updated : 22nd December 2023",
        imgPath: "	https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/b3a8ab85-28b7-4a83-bd8a-eb96d2ed5500/public"
    },


   
]