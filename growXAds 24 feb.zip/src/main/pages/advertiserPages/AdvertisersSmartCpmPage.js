import React from 'react'
import SmartCpm from '../../components/Advertiser/SmartCpm/SmartCpm'

const AdvertisersSmartCpmPage = () => {
    return (
        <div><SmartCpm /></div>
    )
}

export default AdvertisersSmartCpmPage