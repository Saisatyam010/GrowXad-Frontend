import React from 'react'

const ContactUsPage = () => {
  return (
    <>
    <div>Coomponent 1</div>
    <div>Component 2
        <h1>dfsdsgq</h1>
    </div>
    </>
  )
}

export default ContactUsPage