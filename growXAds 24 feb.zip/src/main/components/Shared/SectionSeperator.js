import React from 'react'

const SectionSeperator = () => {
  return (
    <div style={{ margin: "6rem 0rem" }}>

    </div>
  )
}

export default SectionSeperator