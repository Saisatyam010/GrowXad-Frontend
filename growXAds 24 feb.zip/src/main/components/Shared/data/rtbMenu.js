// export const RtbMenu = [

//     { title: "All Ad Formats", imagePath: "https://customer-b0uja279jrdjd4ih.cloudflarestream.com/3d7d87b005035ce9102269b9df88d232/iframe?preload=true&loop=true&autoplay=true&poster=https%3A%2F%2Fcustomer-b0uja279jrdjd4ih.cloudflarestream.com%2F3d7d87b005035ce9102269b9df88d232%2Fthumbnails%2Fthumbnail.jpg%3Ftime%3D%26height%3D600&controls=false" },

//     { title: "Global Reach", imagePath: "https://customer-b0uja279jrdjd4ih.cloudflarestream.com/6e20fad9fe5ccb4edd0789e6a34e5bd5/iframe?muted=true&preload=true&loop=true&autoplay=true&poster=https%3A%2F%2Fcustomer-b0uja279jrdjd4ih.cloudflarestream.com%2F6e20fad9fe5ccb4edd0789e6a34e5bd5%2Fthumbnails%2Fthumbnail.jpg%3Ftime%3D%26height%3D600&controls=false" },

//     { title: "Acquire an Audience", imagePath: "https://customer-b0uja279jrdjd4ih.cloudflarestream.com/459c832a2057a72446467fa32de36415/iframe?preload=true&loop=true&autoplay=true&poster=https%3A%2F%2Fcustomer-b0uja279jrdjd4ih.cloudflarestream.com%2F459c832a2057a72446467fa32de36415%2Fthumbnails%2Fthumbnail.jpg%3Ftime%3D%26height%3D600&controls=false" },

//     { title: "Safe-Guarded", imagePath: "https://customer-b0uja279jrdjd4ih.cloudflarestream.com/5dc42b84ce0a3faa01e82a3c1eb2f1a4/iframe?muted=true&preload=true&loop=true&autoplay=true&poster=https%3A%2F%2Fcustomer-b0uja279jrdjd4ih.cloudflarestream.com%2F5dc42b84ce0a3faa01e82a3c1eb2f1a4%2Fthumbnails%2Fthumbnail.jpg%3Ftime%3D%26height%3D600&controls=false" },
// ];


// images 
export const RtbMenu = [

    { title: "All Ad Formats", imagePath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/4d0b58e6-5861-45a3-a690-bfe931030b00/public", height: 100, width: 100 },

    { title: "Global Reach", imagePath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/0271b844-a37b-4de0-5bfb-a5c3e5fe8300/public", height: 100, width: 100 },

    { title: "Acquire an Audience", imagePath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/57ffeed5-6ec2-461d-9a55-ec3cb525f600/public", height: 100, width: 100 },


    { title: "Safe-Guarded", imagePath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/9113e613-1d84-4ced-b5ed-b224f6c6d800/public", height: 100, width: 100 },

    { title: "Customer Query", imagePath: "https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/2c5e3ba2-8b35-4fca-c2eb-cfdd46a70a00/public", height: 90, width: 70 },
];