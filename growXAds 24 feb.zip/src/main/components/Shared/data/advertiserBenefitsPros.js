export const AdvertiserBenefitsProsData = [
    {
        name: 'VPN & Utilities',
        image: 'https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/bb3901d7-3b74-46f5-dc21-df6b86a3a000/public',
    },
    {
        name: 'Mobile Apps',
        image: 'https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/4eaf578b-ddd0-4c1e-700a-058f7aadf100/public',
    },
    {
        name: 'Dating',
        image: 'https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/8b30caf2-0bb1-43eb-f2bd-52e22ec48b00/public',
    },
    {
        name: 'E-commerce',
        image: 'https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/bb3901d7-3b74-46f5-dc21-df6b86a3a000/public',
    },
    {
        name: 'iGaming',
        image: 'https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/bb3901d7-3b74-46f5-dc21-df6b86a3a000/public',

    },
    {
        name: 'Finance',
        image: 'https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/bb3901d7-3b74-46f5-dc21-df6b86a3a000/public',

    },
    {
        name: 'Subscriptions',
        image: 'https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/5ead73c8-40df-4103-8624-a16638531800/public',

    },
    {
        name: 'Lead Generation',
        image: 'https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/e3023eab-ac49-4256-1603-11683fc46a00/public'
    },
    {
        name: 'Sweepstakes',
        image: 'https://imagedelivery.net/f5tF3V4WaB6L98qcq1rX5w/d08e8a5d-e3a9-45bb-1078-28986c80aa00/public'
    }

]